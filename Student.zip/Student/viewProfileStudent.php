<?php
		$userfullName = $_POST["userfullName"];
		$userIC = $_POST["userIC"];
		$useremail = $_POST["useremail"];
		$usercontactNo= $_POST["usercontactNo"];
		$userage = $_POST["userage"];
		$userGender = $_POST["userGender"];
		$userRace = $_POST["userRace"];
		$userAddress1 = $_POST["userAddress1"];
		$userAddress2 = $_POST["userAddress2"];
		$userpostcode = $_POST["userpostcode"];
		$userstate = $_POST["userstate"];
		$userpassword = $_POST["userpassword"];
		
		

		require_once("allowConfigDB.php");

		$sql = "select * from useraccess(userfullName,userIC,useremail,usercontactNo,userage,userGender,userRace,userAddress1,userAddress2,userpostcode,userstate,userpassword )".
			 "values('$userfullName','$userIC','$useremail','$usercontactNo','$userage','$userGender','$userRace','$userAddress1','$userAddress2','$userpostcode','$userstate','$userpassword')";
?>
<!doctype html>
<html lang="en">
  <head>
  	<title>View Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css" >

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js">
	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js">
<style>
body {
    background: #25162e
}

.form-control:focus {
    box-shadow: none;
    border-color: #BA68C8
}

.profile-button {
    background: rgb(99, 39, 120);
    box-shadow: none;
    border: none
}

.profile-button:hover {
    background: #682773
}

.profile-button:focus {
    background: #682773;
    box-shadow: none
}

.profile-button:active {
    background: #682773;
    box-shadow: none
}

.back:hover {
    color: #682773;
    cursor: pointer
}
input{
		margin-bottom : 14px;
}

.labels {
    font-size: 14px
	font-weight-bold
	margin-bottom : 14px;
}

.add-experience:hover {
    background: #BA68C8;
    color: #fff;
    cursor: pointer;
    border: solid 1px #BA68C8
}
button{
	margin-top : 25px;
width : 150px;
}

</style>
	</head>
	<body>
	<div class="container rounded bg-white mt-5 mb-5">
	<center>
    <div class="column">
        
        <div class="col-md-7 " style = "padding-left : 5%" ><div class="col-md-4 ">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"><span class="font-weight-bold">Welcome<?php echo $userfullName; ?></>,</span>
			<span class="text-black-50"><?php echo $useremail; ?></span><span> </span></div>
        </div>
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile</h4>
                </div>
              
                <div class="row mt-3">
				<div class="col-md-12"><label class="labels">Full Name</label><input type="text" class="form-control" value=<?php echo $userfullName; ?> name="userfullName"></div>
					<div class="col-md-12"><label class="labels">IC Number</label><input type="text" class="form-control" value=<?php echo $userIC; ?> name="userIC"></div>
					<div class="row mt-3">
                    <div class="col-md-6"><label class="labels">Age</label><input type="text" class="form-control" value=<?php echo $userage; ?> name="userage"></div>
                    <div class="col-md-6"><label class="labels">Gender</label><input type="text" class="form-control" value=<?php echo $userGender; ?> name="userGender"></div>
					</div>
                    <div class="col-md-12"><label class="labels">Address</label><input type="text" class="form-control" value=<?php echo $userAddress1; ?> name="userAddress1"></div>
					<div><input type="text" class="form-control" value=<?php echo $userAddress2; ?> name="userAddress2"></div>
					<div class="row mt-3">
                    <div class="col-md-6"><label class="labels">Postcode</label><input type="text" class="form-control" value=<?php echo $userpostcode; ?> name="userpostcode"></div>
                    <div class="col-md-6"><label class="labels">State</label><input type="text" class="form-control" value=<?php echo $userstate; ?> name="userstate"></div>
					</div>
                    <div class="col-md-12"><label class="labels">Race</label><input type="text" class="form-control" value=<?php echo $userRace; ?> name="userRace"></div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6"><label class="labels">Contact Number</label><input type="text" class="form-control" value=<?php echo $usercontactNo; ?> name="usercontactNo"></div>
                    <div class="col-md-6"><label class="labels">Email ID</label><input type="text" class="form-control" value=<?php echo $useremail; ?> name="useremail"></div>
                </div>
				<div class="row mt-3">
                 <div class="col-md-6"><a href="TutorHP.php"><button class="btn btn-primary profile-button" type="button">Back</button></a></div>
				 <div class="col-md-6"><a href="changePassFE.php"><button class="btn btn-primary profile-button" type="update" name="submit">Edit</button></a></div>
            </div>
        </div>
       
    </div>
	</center>
</div>
</div>

	</body>
</html>

