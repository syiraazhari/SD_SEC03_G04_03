<?php 	

$user = $_POST["emailUser"];
$pass = $_POST["passwordUser"];
$newpass = $_POST["newPasswordUser"];

require_once ("allowConfigDB.php");

$result = mysql_query("SELECT useremail, userpassword FROM useraccess WHERE useremail = '$user' and userpassword = '$pass'");

if (!$result) die("SQL query error encountered :".mysql_error() );

$row = mysql_fetch_array($result);
if($row["useremail"]==$user && $row["userpassword"]==$pass)
{
    $query1 = mysql_query("UPDATE useraccess SET userpassword = '$newpass' WHERE useremail = '$user'");
    if (!$query1) die("SQL query error encountered :".mysql_error() );
    echo '<script>alert("Change Password Successful")</script>';
    echo '<script>window.location = "loginUserFE.php"</script>';
    //header('Refresh: 0; URL=loginUserFE.php');
}
else
{
    echo '<script>alert("Wrong username & password!")</script>';
    echo '<script>window.location = "changePassFE.php"</script>';
}

?>