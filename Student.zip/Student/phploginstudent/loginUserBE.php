<?php
$user = $_POST["emailUser"];
$pass = $_POST["passwordUser"];

require_once("allowConfigDB.php");
session_start();

	$result = mysql_query("SELECT useremail, userpassword FROM useraccess WHERE useremail = '$user' and userpassword = '$pass'");

	if (!$result) die("SQL query error encountered :".mysql_error() );

	$row = mysql_fetch_array($result);
	if($row["useremail"]==$user && $row["userpassword"]==$pass)
	{
		$_SESSION["Login"] = $user;
		echo '<script>window.location = "loginUserSuccessFE.php"</script>';
	}
	else
	{
		echo '<script>alert("Wrong username & password!")</script>';
		echo '<script>window.location = "loginUserFE.php"</script>';
	}

?>

