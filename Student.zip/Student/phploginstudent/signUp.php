<!DOCTYPE html>
<html>
<style>

body {
	font-family: Arial, Helvetica, sans-serif ;
	background-image: url(bg.jpg);
	padding-left : 70px;
	padding-right : 70px;
	}
	
	h1 {
  background-color: none;
  color: white;
}
label{
	display: inline-block;
        width: 110px;
}

* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password], input[type=Number], input[type=Address] {
  width: 50%;
  padding: 15px 20px;
  display: inline-block;
  border-style: solid;
  border-radius:30px;
  background: white;
   border: 2px solid #FFFFFF;
  height:50px;
  margin-top: 20px;
  margin-bottom: 20px;

}

input[type=text]:focus, input[type=password]:focus ,input[type=Number]:focus, input[type=Address]:focus {
	
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color:blue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border-radius: 25px;
  border: 2px solid #00000;
  cursor: pointer;
  width: 70%;
  height:50px;
  opacity: 0.9;
}

button:hover {
  opacity:5;

}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: red;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: center;
  width:100px;
}

/* Add padding to container elements */
.container {
  padding: 16px;
 
  
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<div>

<form action="/action_page.php" >
  <div class="container" style="align-content : center">
  
    <b><h1>Sign Up</h1></b>
	
    <b><p style="color:white;">Please fill in this form to create an account."</p></b>
	
    <hr>

<center> 
<div class="column">
	<div><b><label  style="color:white" for="email"><b>Full Name : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Full Name" name="fullName" required></div>
	<div><b><label  style="color:white" for="ic"><b>IC Number : </b></label></b>
    <input class="col-md6" type="number" placeholder="Enter IC Number" name="ic" required></div>
	<div class="row mt-3">
    <div><b><label  style="color:white" for="email"><b>Email : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Email" name="email" required></div>
	<div><b><label  style="color:white;" for="contactNo"><b>Contact Number :</b></label></b>
    <input type="Number" placeholder="Enter Contact Number" name="contactNo" required></div>
	</div>
	 <div><b><label  style="color:white" for="age"><b>Age : </b></label></b>
    <input class="col-md6" type="number" placeholder="Enter Age" name="age" required></div>
	 <div><b><label  style="color:white" for="genderl"><b>Gender : </b></label></b>
	     <input class="col-md6" type="text" placeholder="Enter Age" name="age" required></div>
	 <div><b><label  style="color:white" for="race"><b>Race : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Race" name="race" required></div>
	<div><b><label  style="color:white;" for="Address"><b>Address 1 :</b></label></b>
    <input type="Address" placeholder="Address" name="Address1" required>
	</div>	
	<div><b><label  style="color:white;" for="Address"><b>Address 2 :</b></label></b>
    <input type="Address" placeholder="Address" name="Address2" required>
	</div>
	 <div><b><label  style="color:white" for="postcode"><b>Postcode : </b></label></b>
    <input class="col-md6" type="number" placeholder="Enter Postcode" name="postcode" required></div>
	 <div><b><label  style="color:white" for="state"><b>State : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter State" name="state" required></div>

	
    <div><b><label   style="color:white;"for="psw"><b>Password :</b></label></b>
    <input type="password" placeholder="Enter Password" name="psw" required></div>

    <div><b><label  style="color:white;" for="psw-repeat"><b>Re-Type :</b></label></b>
    <input type="password" placeholder="Repeat Password" name="psw-repeat" required></div>

    
     <b><p style="color:white;"> <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px" > Remember me</p><b>
   

    <b><p style="color:white;" >By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p></b>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
</center>
  </div>
</form>
</div></center>

</body>
</html>
