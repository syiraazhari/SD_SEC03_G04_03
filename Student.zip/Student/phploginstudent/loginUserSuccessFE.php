
<h1 style="text-align:center;">LOGIN SUCCESSFUL</h1>

<style>
img {
  margin: 0 auto;
  display: block;
  margin-top: 20%;
}
</style>
