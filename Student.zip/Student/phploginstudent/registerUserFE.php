<!DOCTYPE html>
<html>
<style>

body {
	font-family: Arial, Helvetica, sans-serif ;
	}
	
	h1 {
  background-color: none;
  color: white;
}

* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password], input[type=Number], input[type=Address] {
  width: 60%;
  padding: 15px 20px;
  display: inline-block;
  border-style: solid;
  border-radius:30px;
  background: white;
   border: 2px solid #FFFFFF;
  height:50px;
  margin-top: 20px;
  margin-bottom: 20px;

}

input[type=text]:focus, input[type=password]:focus ,input[type=Number]:focus, input[type=Address]:focus {
	
  outline: none;
  

}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color:blue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border-radius: 25px;
  border: 2px solid #00000;
  cursor: pointer;
  width: 70%;
  height:50px;
  opacity: 0.9;
}

button:hover {
  opacity:5;

}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: red;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: center;
  width:100px;
}

/* Add padding to container elements */
.container {
  padding: 16px;
 
  
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }


 
}
</style>
<body>

<div  style="background-image: url(bg.jpg);"> 
<form name="form1" method="POST" action="registerUserBE.php" enctype="multipart/form-data">
  <div class="container" style="align-content : center">
  
    <b><h1>Sign Up</h1></b>
	
    <b><p style="color:white;">Please fill in this form to create an account."</p></b>
	
    <hr>

<center>
	<div><b><label  style="color:white" for="email"><b>Full Name : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Full Name" name="userfullName" required></div>

	<div><b><label  style="color:white" for="ic"><b>IC Number : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter IC Number" name="userIC" required></div>

    <div><b><label  style="color:white" for="email"><b>Email: </b></label></b>
    <input type="text" placeholder="Enter Email" name="useremail" required></div>
	
	<div><b><label  style="color:white;" for="contactNo"><b>Contact Number :</b></label></b>
    <input type="Number" placeholder="Enter Contact Number" name="usercontactNo" required></div>

<div><b><label  style="color:white" for="age"><b>Age : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Age" name="userage" required></div>

<div><b><label  style="color:white" for="genderl"><b>Gender : </b></label></b>
	     <input class="col-md6" type="text" placeholder="Enter Gender" name="userGender" required></div>

<div><b><label  style="color:white" for="race"><b>Race : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Race" name="userRace" required></div>

<div><b><label  style="color:white;" for="Address"><b>Address 1 :</b></label></b>
    <input type="Address" placeholder="Address" name="userAddress1" required>
	</div>

<div><b><label  style="color:white;" for="Address"><b>Address 2 :</b></label></b>
    <input type="Address" placeholder="Address" name="userAddress2" required>
	</div>

<div><b><label  style="color:white" for="postcode"><b>Postcode : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter Postcode" name="userpostcode" required></div>

<div><b><label  style="color:white" for="state"><b>State : </b></label></b>
    <input class="col-md6" type="text" placeholder="Enter State" name="userstate" required></div>

    <div><b><label   style="color:white;"for="psw"><b>Password:</b></label></b>
    <input type="password" placeholder="Enter Password" name="userpassword" required></div>

    <div><b><label  style="color:white;" for="psw-repeat"><b>Re-Type:</b></label></b>
    <input type="password" placeholder="Repeat Password" name="userpassword-repeat" required></div>
	
    </center>

    <label>
     <b><p style="color:white;"> <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px" > Remember me</p><b>
    </label>
    <center>
    <b><p style="color:white;" >By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p></b>

    <div class="clearfix">
      <button type="button" class="cancelbtn">Cancel</button>
      <button type="submit" class="signupbtn">Sign Up</button>
    </div>
</center>
  </div>
</form>
</div></center>

</body>
</html>
