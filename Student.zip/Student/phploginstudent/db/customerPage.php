<html>
<head><title>DobbyMe Information</title><link rel="stylesheet" type="text/css" href="style.css">
</head>

<?php
require_once("config.php");
session_start();
$email = $_SESSION["Login"];

$query = mysql_query("select * from Customer where custEmail='$email'");
if(!$query) die("SQL query error encountered :".mysql_error());
$record = mysql_fetch_array($query);
$cemail = $record["custEmail"];
$password = $record["custPassword"];
$cname = $record["custFullName"];
$phone = $record["custPhone"];
$address = $record["custAddress"];
?>

<script>
	function editForm1(){
		var x = document.getElementById('edit1');
		x.style.display = 'none';
		document.getElementById('t1').readOnly = false;
		document.getElementById("t1").style.backgroundColor = "red";
		var y = document.getElementById('save1');
		var z = document.getElementById('cancel1');
		y.style.display = '';
		z.style.display = '';
	}

	function cancelForm1(){
		document.getElementById('t1').readOnly = true;
		document.getElementById("t1").style.backgroundColor = "white";
		var y = document.getElementById('save1');
		var z = document.getElementById('cancel1');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit1');
		x.style.display = '';

	}

	function save1(){
		document.getElementById('t1').readOnly = true;
		document.getElementById("t1").style.backgroundColor = "white";
		var y = document.getElementById('save1');
		var z = document.getElementById('cancel1');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit1');
		x.style.display = '';
	}
	/////////////////////////////////////////////////////////////
		function editForm2(){
		var x = document.getElementById('edit2');
		x.style.display = 'none';
		document.getElementById('t2').readOnly = false;
		document.getElementById("t2").style.backgroundColor = "red";
		var y = document.getElementById('save2');
		var z = document.getElementById('cancel2');
		y.style.display = '';
		z.style.display = '';
	}

	function cancelForm2(){
		document.getElementById('t2').readOnly = true;
		document.getElementById("t2").style.backgroundColor = "white";
		var y = document.getElementById('save2');
		var z = document.getElementById('cancel2');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit2');
		x.style.display = '';

	}

	function save2(){
		document.getElementById('t2').readOnly = true;
		document.getElementById("t2").style.backgroundColor = "white";
		var y = document.getElementById('save2');
		var z = document.getElementById('cancel2');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit2');
		x.style.display = '';
	}
	/////////////////////////////////////////////////////////////
		function editForm3(){
		var x = document.getElementById('edit3');
		x.style.display = 'none';
		document.getElementById('t3').readOnly = false;
		document.getElementById("t3").style.backgroundColor = "red";
		var y = document.getElementById('save3');
		var z = document.getElementById('cancel3');
		y.style.display = '';
		z.style.display = '';
	}

	function cancelForm3(){
		document.getElementById('t3').readOnly = true;
		document.getElementById("t3").style.backgroundColor = "white";
		var y = document.getElementById('save3');
		var z = document.getElementById('cancel3');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit3');
		x.style.display = '';

	}

	function save3(){
		document.getElementById('t3').readOnly = true;
		document.getElementById("t3").style.backgroundColor = "white";
		var y = document.getElementById('save3');
		var z = document.getElementById('cancel3');
		y.style.display = 'none';
		z.style.display = 'none';
		var x = document.getElementById('edit3');
		x.style.display = '';
	}


</script>

<div id="pagesize1">

<body>
	<div id="head"></div>
	<div id="box_2">

		<fieldset style="display: inline-flex;">
		<legend><h1>Customer Information</h1></legend>

<table style="width:100%" border="1px">
<a href='customerMainPage.php'><input class="button1" type="submit" value="BACK"/></a>
<?php
					require_once("config.php");

					$qry = "select * from Customer where custEmail='$email'";
					$result = mysql_query($qry);

					while($row=mysql_fetch_array($result))
					{
						echo '<tr><td><img height="100" width="100" src="data:image;base64,'.$row[6].'"></td>';
					}

		?>

<td colspan="2"></td></tr>
  <tr><td><b>Email</b></td>
     <td colspan="2"><p><?php echo $cemail?></p></td></tr>
  <tr><td><b>Full Name</b></td>
    <td colspan="2"><p><?php echo $cname?></td></tr>

  <tr><td><b>Password</b></td>
  <form name="form1" method="POST" action="upCustPass.php">
    <td><input id="t1" name="password" type="password" value="<?php echo $password?>" readonly></td>
    <td><button type="button" id="edit1" onclick="editForm1();" style="width:180px"><b>Edit</b></button>
							<button id="save1" style="width:90px;display:none;"><b>Save</b></button>
							<button type="button" id="cancel1" onclick="cancelForm1();" style="width:90px;display:none;"><b>Cancel</b></button></td></tr>
	</form>

  <tr><td><b>Mobile No.</b></td>
  <form name="form2" method="POST" action="upCustPhone.php">
    <td><input id="t2" name="phone" type="text" value="<?php echo $phone?>" readonly></td>
    <td><button type="button" id="edit2" onclick="editForm2();" style="width:180px"><b>Edit</b></button>
							<button id="save2" style="width:90px;display:none;"><b>Save</b></button>
							<button type="button" id="cancel2" onclick="cancelForm2();" style="width:90px;display:none;"><b>Cancel</b></button></td></tr>
	</form>


   <tr><td><b>Address</b></td>
  <form name="form3" method="POST" action="upCustAdd.php">
    <td><input id="t3" name="add" type="text" value="<?php echo $address?>" readonly></td>
    <td><button type="button" id="edit3" onclick="editForm3();" style="width:180px"><b>Edit</b></button>
							<button id="save3" style="width:90px;display:none;"><b>Save</b></button>
							<button type="button" id="cancel3" onclick="cancelForm3();" style="width:90px;display:none;"><b>Cancel</b></button></td></tr>


	</form>
</table>


	</div>
</body>

</div>
</html>
