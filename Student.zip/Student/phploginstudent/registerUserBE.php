<?php

		$userfullName = $_POST["userfullName"];
		$userIC = $_POST["userIC"];
		$useremail = $_POST["useremail"];
		$usercontactNo= $_POST["usercontactNo"];
		$userage = $_POST["userage"];
		$userGender = $_POST["userGender"];
		$userRace = $_POST["userRace"];
		$userAddress1 = $_POST["userAddress1"];
		$userAddress2 = $_POST["userAddress2"];
		$userpostcode = $_POST["userpostcode"];
		$userstate = $_POST["userstate"];
		$userpassword = $_POST["userpassword"];
		
		

		require_once("allowConfigDB.php");

		$sql = "insert IGNORE into useraccess(userfullName,userIC,useremail,usercontactNo,userage,userGender,userRace,userAddress1,userAddress2,userpostcode,userstate,userpassword )".
			 "values('$userfullName','$userIC','$useremail','$usercontactNo','$userage','$userGender','$userRace','$userAddress1','$userAddress2','$userpostcode','$userstate','$userpassword')";

		$query = mysql_query($sql);
		if(!$query) die("SQL Query Error Encountered: ".mysql_error());

			echo '<script>alert("Registration Successful")</script>';
			echo '<script>window.location = "loginUserFE.php"</script>';
?>
