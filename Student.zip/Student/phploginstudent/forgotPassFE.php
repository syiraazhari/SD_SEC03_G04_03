<!DOCTYPE html>
<html>
<style>

body {
	font-family: Arial, Helvetica, sans-serif ;
	background-image: url(bg.jpg);
	padding-left : 70px;
	padding-right : 70px;
	}
	
	h1 {
  background-color: none;
  color: white;
}
label{
	display: inline-block;
        width: 110px;
}

* {box-sizing: border-box}

/* Full-width input fields */
input[type=text], input[type=password], input[type=Number], input[type=Address] {
  width: 50%;
  padding: 15px 20px;
  display: inline-block;
  border-style: solid;
  border-radius:30px;
  background: white;
   border: 2px solid #FFFFFF;
  height:50px;
  margin-top: 20px;
  margin-bottom: 20px;

}

input[type=text]:focus, input[type=password]:focus ,input[type=Number]:focus, input[type=Address]:focus {
	
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color:blue;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border-radius: 25px;
  border: 2px solid #00000;
  cursor: pointer;
  width: 70%;
  height:50px;
  opacity: 0.9;
}

button:hover {
  opacity:5;

}



/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: center;
  width:200px;
}

/* Add padding to container elements */
.container {
  padding: 16px;
 
  
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<div>

<form method="post" action="forgotPassBE.php" >
  <div class="container" style="align-content : center">
  
    <b><h1>Change Password</h1></b>
    <hr>
<center> 
<div class="column">
  <div class="form-group">
    <b><label  style="color:white" ><b>Email : </b></label></b>
    <input type="text" class="form-control" placeholder="email" id="emailUser" name="emailUser" required>
  </div>            
    <div class="form-group">
      <button type="submit" class="form-control btn btn-primary submit px-3" value="login">Retrieve Password</button>
    </div>
</center>
  </div>
</form>
</div></center>

</body>
</html>
