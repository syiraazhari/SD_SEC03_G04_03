<?php
	$conn = mysql_connect("localhost","ainnn","ainnn_123");
		if(!$conn) die ("Error! Cannot connect to server: ".mysql_error());
	$selected = mysql_select_db("db_ainnn", $conn);
		if(!$selected) die ("cannot use database: ".mysql_error());
?>