<?php $__env->startComponent($view, $params); ?>
    <?php $__env->slot($slotOrSection); ?>
        <?php echo $manager->initialDehydrate()->toInitialResponse()->effects['html']; ?>

    <?php $__env->endSlot(); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\vendor\livewire\livewire\src/Macros/livewire-view-component.blade.php ENDPATH**/ ?>