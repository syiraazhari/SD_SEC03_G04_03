<section class="hero">
    <div class="container position-relative">
        <div class="row gy-5" data-aos="fade-in">
            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                <h2><span>Manage Schedule</span></h2>
                <p>Your Class Schedule will be display here</p>
            </div>
        </div>
    </div>

    <div class="icon-boxes position-relative">
        <div class="container position-relative">
            <div class="row gy-4 mt-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="tutor-box">

                        <div class="col-12">
                            <div class="info-container d-flex flex-column align-items-center justify-content-center">
                                
                                <div class="info-item">
                                    <div>
                                        <h4>Daily Schedule</h4>
                                        <select name="day" id="day" class="daily-item d-flex" >
                                            <option value="">Select Day</option>
                                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($day->day); ?>"><?php echo e($day->day); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if(Session::has('message')): ?>
                                            <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                                        <?php endif; ?>
                                        <div class="text-center">
                                            <a href="<?php echo e(route('admin.addSchedule')); ?>" class="link">Add New</a>
                                        </div>
                                    </div>
                                </div><!-- End Info Item -->
                                
                                <div id="Monday" class="info-item data">
                                    <div>
                                        <h4>Monday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $mondays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($monday->time); ?></td>
                                                        <td><?php echo e($monday->subject); ?></td>
                                                        <td><?php echo e($monday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Tuesday" class="info-item data">
                                    <div>
                                        <h4>Tuesday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $tuesdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuesday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($tuesday->time); ?></td>
                                                        <td><?php echo e($tuesday->subject); ?></td>
                                                        <td><?php echo e($tuesday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Wednesday" class="info-item data">
                                    <div>
                                        <h4>Wednesday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $wednesdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wednesday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($wednesday->time); ?></td>
                                                        <td><?php echo e($wednesday->subject); ?></td>
                                                        <td><?php echo e($wednesday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Thursday" class="info-item data">
                                    <div>
                                        <h4>Thursday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $thursdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thursday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($thursday->time); ?></td>
                                                        <td><?php echo e($thursday->subject); ?></td>
                                                        <td><?php echo e($thursday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Friday" class="info-item data">
                                    <div>
                                        <h4>Friday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $fridays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $friday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($friday->time); ?></td>
                                                        <td><?php echo e($friday->subject); ?></td>
                                                        <td><?php echo e($friday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Saturday" class="info-item data">
                                    <div>
                                        <h4>Saturday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $saturdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saturday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($saturday->time); ?></td>
                                                        <td><?php echo e($saturday->subject); ?></td>
                                                        <td><?php echo e($saturday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->

                                <div id="Sunday" class="info-item data">
                                    <div>
                                        <h4>Sunday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Time</th>
                                                    <th scope="col">Subject</th>
                                                    <th scope="col">Tutor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $sundays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sunday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($sunday->time); ?></td>
                                                        <td><?php echo e($sunday->subject); ?></td>
                                                        <td><?php echo e($sunday->tutor); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div>
                                </div><!-- End Info Item -->
                            </div>
        
                        </div>

                    </div>
                </div>
                <!--End Icon Box -->
            </div>
        </div>
    </div>

</section>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){
            $("#day").on('change', function(){
                $(".data").hide();
                $("#" + $(this).val()).fadeIn(700);
            });
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\resources\views/livewire/student/class/student-schedule-component.blade.php ENDPATH**/ ?>