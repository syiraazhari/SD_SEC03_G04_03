<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>