
<section class="hero">
    <div class="container position-relative">
        <div class="row gy-5" data-aos="fade-in">
            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                <h2><span>Attendance List</span></h2>
                <p>Your Class Attendance List will be display here.</p>
            </div>
        </div>
    </div>

    <div class="icon-boxes position-relative">
        <div class="container position-relative">
            <div class="row gy-4 mt-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="tutor-box">

                        <div class="col-12">
                            <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                                <?php endif; ?>
                            <div class="info-container d-flex flex-column align-items-center justify-content-center">
                                <form class="info-item" wire:submit.prevent="findAttendance">
                                    <div >
                                        <h4>Select Attendance</h4>
                                        <select name="day" id="day" class="daily-item d-flex">
                                            <option value="">Select Day</option>
                                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($day->day); ?>"><?php echo e($day->day); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <select name="" id="" class="daily-item d-flex">
                                            <option value="">Select Subjects</option>
                                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subject->subject); ?>"><?php echo e($subject->subject); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div><!-- End Info Item -->
                                    <div class="info-item">
                                        <div class="text-center">
                                            <button type="submit">Submit</button>
                                        </div>
                                    </div><!-- End Info Item -->
                                </form>

                                
                                <div id="Monday" class="info-item data">
                                    <div>
                                        <h4>Monday</h4>
                                        <table class="table table-hover">
                                            <thead>
                                                <tr>
                                                    <th scope="col">Name</th>
                                                    <th scope="col">Present</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                    <tr>
                                                        <td>Tawik</td>
                                                        <td>Present</td>
                                                    </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- End Info Item -->

                                
                                
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Icon Box -->
            </div>
        </div>
    </div>

</section>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){
            $("#day").on('change', function(){
                $(".data").hide();
                $("#" + $(this).val()).fadeIn(700);
            });
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\resources\views/livewire/tutor/attendance/tutor-attendance-component.blade.php ENDPATH**/ ?>