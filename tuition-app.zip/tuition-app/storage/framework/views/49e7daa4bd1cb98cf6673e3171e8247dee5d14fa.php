
<section class="hero">
    <div class="container position-relative">
        <div class="row gy-5" data-aos="fade-in">
            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                <h2><span>Attendance</span></h2>
                <p>Don't Forget to fill Attendance Form</p>
            </div>
        </div>
    </div>

    <div class="icon-boxes position-relative">
        <div class="container position-relative">
            <div class="row gy-4 mt-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="tutor-box">

                        <div class="col-12">
                            <div class="info-container d-flex flex-column align-items-center justify-content-center">
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success" role="alert"><?php echo e(Session::get('message')); ?></div>
                                <?php endif; ?>
                                <form class="info-item" enctype="multipart/form-data" wire:submit.prevent="storeAttendance">
                                    <div>
                                        <h4>Submit Attendance</h4>
                                        <select name="" id="" class="daily-item d-flex" wire:model="day">
                                            <option value="">Select Day</option>
                                            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($day->day); ?>"><?php echo e($day->day); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <select name="" id="" class="daily-item d-flex" wire:model="time">
                                            <option value="">Select Time</option>
                                            <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($time->time); ?>"><?php echo e($time->time); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <select name="" id="" class="daily-item d-flex" wire:model="subject">
                                            <option value="">Select Subjects</option>
                                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($subject->subject); ?>"><?php echo e($subject->subject); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <select name="" id="" class="daily-item d-flex" wire:model="status">
                                            <option value="">Select Status</option>
                                            <option value="Present">Present</option>
                                            <option value="Absent">Absent</option>
                                        </select>
                                    </div>
                                    <div class="info-item">
                                        <div class="text-center">
                                            <button type="submit">Submit</button>
                                        </div>
                                    </div><!-- End Info Item -->
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End Icon Box -->
            </div>
        </div>
    </div>

</section><?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\resources\views/livewire/student/form/attendance-component.blade.php ENDPATH**/ ?>