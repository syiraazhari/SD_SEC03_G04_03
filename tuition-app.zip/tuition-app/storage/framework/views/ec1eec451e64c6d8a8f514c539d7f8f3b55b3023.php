
<section class="hero">
    <div class="container position-relative">
        <div class="row gy-5" data-aos="fade-in">
            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                <h2><span>Student's List</span></h2>
                <p>Your Student list will be display here</p>
            </div>
        </div>
    </div>

    <div class="icon-boxes">
        <div class="container">
            <div class="row gy-4 mt-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="tutor-box">

                        <div class="col-12">
                            <div class="info-container d-flex flex-column align-items-center justify-content-center">
                                <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="info-item d-flex">
                                        <img src="<?php echo e(asset('assets/img/testimonials/testimonials-1.jpg')); ?>" class="tutor-img flex-shrink-0" alt="Tutor Img">
                                        <div>
                                            <h4><?php echo e($item->name); ?></h4>
                                            <p>Gender: <?php echo e($item->gender); ?></p>
                                            <p>Phone: <?php echo e($item->phone); ?></p>
                                        </div>
                                    </div><!-- End Info Item -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
        
                        </div>

                    </div>
                </div>
                <!--End Icon Box -->
            </div>
        </div>
    </div>

    </div>
</section><?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\resources\views/livewire/tutor/student-list/student-list-component.blade.php ENDPATH**/ ?>