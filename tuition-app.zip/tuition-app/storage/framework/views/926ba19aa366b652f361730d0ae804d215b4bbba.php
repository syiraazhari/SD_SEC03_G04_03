<?php echo e($slot); ?>

<?php /**PATH D:\My Project\Framework\Laravel\SEC 40 - Tuition Management\tuition-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>