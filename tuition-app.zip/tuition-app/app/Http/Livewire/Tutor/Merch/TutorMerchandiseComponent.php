<?php

namespace App\Http\Livewire\Tutor\Merch;

use Livewire\Component;

class TutorMerchandiseComponent extends Component
{
    public function render()
    {
        return view('livewire.tutor.merch.tutor-merchandise-component')->layout('layouts.base');
    }
}
