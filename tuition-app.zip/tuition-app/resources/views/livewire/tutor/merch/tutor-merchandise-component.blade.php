<section class="hero">
    <div class="container position-relative">
        <div class="row gy-5" data-aos="fade-in">
            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center text-center text-lg-start">
                <h2><span>Tutor Merchandise</span></h2>
                <p>Your Merchandise will be display here.</p>
            </div>
        </div>
    </div>

    <div class="icon-boxes position-relative">
        <div class="container position-relative">
            <div class="row gy-4 mt-5">
                <div class="col-12" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon-box">
                    <div class="icon"><i class="bi bi-easel"></i></div>
                    <h4 class="title"><a href="" class="stretched-link">Lorem Ipsum</a></h4>
                    </div>
                </div>
                <!--End Icon Box -->
            </div>
        </div>
    </div>

    </div>
</section>