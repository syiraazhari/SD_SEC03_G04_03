<?php
$files=scandir("classTutor1");
for($a=2;$a<count($files);$a++)
{
	?>
	<p>
	<?php echo $files[$a];?>
	<a href="classTutor1/<?php echo $files[$a];?>"download="<?php echo $files[$a];?>">
	<button>Download</button>
	</a>
	</p>
	<?php
}
?>