<!DOCTYPE html>

<html lang="zxx">
<head>

  <!-- ** Basic Page Needs ** -->
  <meta charset="utf-8">
  <title>Megakit | HTML5 Agency Template</title>

  <!-- ** Mobile Specific Metas ** -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Agency HTML Template">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <meta name="author" content="Themefisher">
  <meta name="generator" content="Themefisher Html5 Agency Template v1.0">

  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <!-- Icon Font Css -->
  <link rel="stylesheet" href="plugins/themify/css/themify-icons.css">
  <link rel="stylesheet" href="plugins/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="plugins/magnific-popup/magnific-popup.css">
  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="plugins/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick/slick-theme.css">

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="css/style.css">
  
  <!--Favicon-->
  <link rel="icon" href="images/favicon.png" type="image/x-icon">

</head>

<body>

<!-- Header Start -->
<header class="navigation">

   <div id="navbar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <nav class="navbar navbar-expand-lg px-0 py-4">
            <a class="navbar-brand" href="index.html">
			<img src="images\logo.png" alt="logo" name="logo">
            </a>
      
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExample09"
              aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
              <span class="fa fa-bars"></span>
            </button>
      
            <div class="collapse navbar-collapse text-center" id="navbarsExample09">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item ">
                  <a class="nav-link" href="../../project123/Guest/GuestHP.php">Home</a>
                </li>
                <li class="nav-item @@service"><a class="nav-link" href="subscription.php">SUBSCRIPTION</a></li>
                <li class="nav-item active"><a class="nav-link" href="tutorGuest.php">TUTOR</a></li>
				<li class="nav-item @@contact"><a class="nav-link" href="contact.html">SHOP</a></li>
				 <li class="nav-item @@contact"><a class="nav-link" href="contactguest.php">CONTACT US</a></li>
              </ul>
      
              <div class="my-2 my-md-0 ml-lg-4 text-center">
                  <a class="btn btn-solid-border btn-round-full @@about" href="../../project123/phplogin/loginUserFE.php" aria-haspopup="true" aria-expanded="false">LOG IN</a>
      
              </div>
			   
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Header Close -->

<section class="page-title bg-1">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block text-center">
          <span class="text-white">Introducing our</span>
          <h1 class="text-capitalize mb-4 text-lg">Tutors</h1>
      
        </div>
      </div>
    </div>
  </div>
</section>

<!-- section portfolio start -->
<section class="section portfolio pb-0" >
<div style="background-image: url('bg.jpg');">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7 text-center">
				<div class="section-title">
					<span class="h6 text-color">Our tutors</span>
					<h2 class="mt-3 content-title">We picked the best tutors among the best for our students</h2>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row portfolio-gallery">
			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor1.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor1.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Erfan</h3>
							<p class="text-white-50">Mathematics F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile1.php" class="btn btn-main btn-round-full" >View Profile</a></center>
					</div>
					<br><br><br><br><br>
			</div>
					
			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor2.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor2.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Wazif</h3>
							<p class="text-white-50">Mathematics F4&F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile2.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>

			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor3.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor3.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Afiq</h3>
							<p class="text-white-50">Mathematics F4&F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile3.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>

			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor4.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor4.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Aizuddin</h3>
							<p class="text-white-50">Mathematics F3</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile4.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br><br><br><br><br>
			</div>

			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative  mb-4">
					<a href="images/portfolio/tutor5.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor5.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Dennish</h3>
							<p class="text-white-50">Additional Mathematics F4</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile5.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>

			<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor6.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor6.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Aideen</h3>
							<p class="text-white-50">Additional Mathematics F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile6.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>
			
				<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor7.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor7.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Afiq</h3>
							<p class="text-white-50">Mathematics F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile7.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>
			
				<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor8.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor8.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Afiq</h3>
							<p class="text-white-50">Mathematics F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile8.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br>
			</div>
			
				<div class="col-lg-4 col-md-6">
				<div class="portflio-item position-relative mb-4">
					<a href="images/portfolio/tutor9.jpeg" class="popup-gallery">
						<img src="images/portfolio/tutor9.jpeg" alt="portfolio" class="img-fluid w-100">

						<i class="ti-plus overlay-item"></i>
						<div class="portfolio-item-content">
							<h3 class="mb-0 text-white">Tutor Afiq</h3>
							<p class="text-white-50">Mathematics F4&F5</p>
						</div>
					</a>
				</div>
				<div><center>
					<a href="../../project123/Guest/tutorProfile9.php" class="btn btn-main btn-round-full">View Profile</a></center>
					</div>
					<br><br><br><br><br>
			</div>
		</div>
	</div>
	</div>
</section>
<!-- section portfolio END -->

<footer class="footer section">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Company</h4>

          <ul class="list-unstyled footer-menu lh-35">
            <li><a href="about.html">Terms & Conditions</a></li>
            <li><a href="about.html">Privacy Policy</a></li>
            <li><a href="cobtact.html">Support</a></li>
            <li><a href="cobtact.html">FAQ</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-2 col-md-6 col-sm-6">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Quick Links</h4>

          <ul class="list-unstyled footer-menu lh-35">
            <li><a href="about.html">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="blog-grid.html">Blogs</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6 mx-auto">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Subscribe Us</h4>
          <p>Subscribe to get latest news article and resources </p>

          <form action="#" class="sub-form">
            <input type="text" class="form-control mb-3" placeholder="Subscribe Now ...">
            <a href="#" class="btn btn-main btn-small">subscribe</a>
          </form>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6">
        <div class="widget">
          <div class="logo mb-4">
            <h3>Mega<span>kit.</span></h3>
          </div>
          <h6><a href="mailto:support@gmail.com">Support@megakit.com</a></h6>
          <a href="tel:+23-345-67890"><span class="text-color h4">+23-456-6588</span></a>
        </div>
      </div>
    </div>

    <div class="footer-btm pt-4">
      <div class="row">
        <div class="col-lg-6">
          <div class="copyright">
            Copyright &copy; 2020, Designed &amp; Developed by <a href="https://themefisher.com/"
              >Themefisher</a>
          </div>
        </div>
        <div class="col-lg-6 text-left text-lg-right">
          <ul class="list-inline footer-socials">
            <li class="list-inline-item"><a href="https://www.facebook.com/themefisher"><i class="fab fa-facebook-f mr-2"></i>Facebook</a></li>
            <li class="list-inline-item"><a href="https://twitter.com/themefisher"><i class="fab fa-twitter mr-2"></i>Twitter</a></li>
            <li class="list-inline-item"><a href="https://www.pinterest.com/themefisher/"><i class="fab fa-pinterest-p mr-2 "></i>Pinterest</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--Scroll to top-->
<div id="scroll-to-top" class="scroll-to-top">
  <span class="icon fa fa-angle-up"></span>
</div>


<!-- 
Essential Scripts
=====================================-->
<!-- Main jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4.3.1 -->
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<!--  Magnific Popup-->
<script src="plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
<!-- Slick Slider -->
<script src="plugins/slick/slick.min.js"></script>
<!-- Counterup -->
<script src="plugins/counterup/jquery.waypoints.min.js"></script>
<script src="plugins/counterup/jquery.counterup.min.js"></script>

<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU" defer></script>
<script src="plugins/google-map/map.js" defer></script>

<script src="js/script.js"></script>

</body>

</html>