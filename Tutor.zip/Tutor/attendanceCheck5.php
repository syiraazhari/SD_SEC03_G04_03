<!DOCTYPE html>

<!--
 // WEBSITE: https://themefisher.com
 // TWITTER: https://twitter.com/themefisher
 // FACEBOOK: https://www.facebook.com/themefisher
 // GITHUB: https://github.com/themefisher/
-->

<html lang="zxx">
<head>

  <!-- ** Basic Page Needs ** -->
  <meta charset="utf-8">
  <title>Megakit | HTML5 Agency Template</title>

  <!-- ** Mobile Specific Metas ** -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Agency HTML Template">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  <meta name="author" content="Themefisher">
  <meta name="generator" content="Themefisher Html5 Agency Template v1.0">

  <!-- bootstrap.min css -->
  <link rel="stylesheet" href="plugins/bootstrap/bootstrap.min.css">
  <!-- Icon Font Css -->
  <link rel="stylesheet" href="plugins/themify/css/themify-icons.css">
  <link rel="stylesheet" href="plugins/fontawesome/css/all.min.css">
  <link rel="stylesheet" href="plugins/magnific-popup/magnific-popup.css">
  <!-- Owl Carousel CSS -->
  <link rel="stylesheet" href="plugins/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick/slick-theme.css">

  <!-- Main Stylesheet -->
  <link rel="stylesheet" href="css/style.css">
  
  <!--Favicon-->
  <link rel="icon" href="images/favicon.png" type="image/x-icon">

</head>
<style>
body{
  background: #ecf0f1;
  font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;
  font-size: 16px;
}
.holder{
  background: #fff;
  border-radius:5px; 	
  box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);	
  margin:100px auto;
  padding:30px 20px 20px;
  width:700px;
}
td{
  border-bottom:1px solid #f6f6f6;
  padding:5px 10px;
}
tr:last-child td{
  border:none;  
}
.attendance>input[type=checkbox] {
  cursor: pointer;
  height: 30px;
  margin:4px 0 0;
  position: absolute;
  opacity: 0;
  width: 30px;
  z-index: 2;
}

.attendance>input[type=checkbox] + span {
  background: #e74c3c;
  border-radius: 50%;
  box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);
  display: inline-block;
  height: 20px;
  margin:4px 0 0;
  position:relative;
  width: 20px;
  transition: all .2s ease;
}
.attendance>input[type=checkbox] + span::before, .attendance>input[type=checkbox] + span::after{
  background:#fff;
  content:'';
  display:block;
  position:absolute;
  width:2px;
  transition: all .2s ease;
}
.attendance>input[type=checkbox] + span::before{
  height:12px;
  left:9px;
  top:4px;
  -webkit-transform:rotate(-45deg);
  transform:rotate(-45deg);
}
.attendance>input[type=checkbox] + span::after{
  height:12px;
  right:9px;
  top:4px;
  -webkit-transform:rotate(45deg);
  transform:rotate(45deg);
}
.attendance>input[type=checkbox]:checked + span {
  background:#2ecc71;			    
}
.attendance>input[type=checkbox]:checked + span::before{
  height: 7px;
  left: 6px;
  top: 8px;
  -webkit-transform:rotate(-47deg);
  transform:rotate(-47deg);
}
.attendance>input[type=checkbox]:checked + span::after{
  height: 11px;
  right: 6px;
  top: 4px;
}
</style>
<body>

<!-- Header Start -->
<header class="navigation">
<div id="navbar">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <nav class="navbar navbar-expand-lg px-0 py-4">
            <a class="navbar-brand" href="index.html">
			<img src="images\logo.png" alt="logo" name="logo">
            </a>
      
            <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarsExample09"
              aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
              <span class="fa fa-bars"></span>
            </button>
      
            <div class="collapse navbar-collapse text-center" id="navbarsExample09">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                  <a class="nav-link" href="index.html">Home</a>
                </li>
                <li class="nav-item @@service"><a class="nav-link" href="student.php">CLASS</a></li>
                <li class="nav-item @@project"><a class="nav-link" href="student.php">STUDENT</a></li>
				<li class="nav-item @@contact"><a class="nav-link" href="contact.html">MATERIAL</a></li>
				 <li class="nav-item @@contact"><a class="nav-link" href="viewProfileTutor.php">PROFILE</a></li>
              </ul>
      
            
			   <div class="my-2 my-md-0 ml-lg-4 text-center">
                <a href="../../project123/Guest/GuestHP.php" class="btn btn-solid-border btn-round-full">Log Out</a>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>
<!-- Header Close -->

<!--  Section Services Start -->
<div style="background-image:url('bg.jpg');">
<section class="section service border-top pb-5">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7 text-center">
				<div class="section-title">

					<h2 class="mt-3 content-title text-color">The attendance for Friday</h2>
				</div>
			</div>
		</div>

		<div class="holder text-center">
			<table width="100%">
        <thead><tr>
          <td>Name</td>
          <td></td>
          <td>Attendance</td>
          <td></td>
					<td>
          </tr>
        </thead>
          <tbody>
					<tr>
					<td>Member</td>
					<td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance text-center">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					<tr>
					<td>Member</td>
					<td>
					</td>
					<td>
						<div class="attendance">
							<input type="checkbox" />
						    <span></span>
						</div>
					</td>
					</tr>
					
            </tbody>
			</table>
</div>

	</div>
</section>
</div>
<!--  Section Services End -->



<footer class="footer section">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-md-6 col-sm-6">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Company</h4>

          <ul class="list-unstyled footer-menu lh-35">
            <li><a href="about.html">Terms & Conditions</a></li>
            <li><a href="about.html">Privacy Policy</a></li>
            <li><a href="cobtact.html">Support</a></li>
            <li><a href="cobtact.html">FAQ</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-2 col-md-6 col-sm-6">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Quick Links</h4>

          <ul class="list-unstyled footer-menu lh-35">
            <li><a href="about.html">About</a></li>
            <li><a href="service.html">Services</a></li>
            <li><a href="blog-grid.html">Blogs</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="col-lg-3 col-md-6 col-sm-6 mx-auto">
        <div class="widget">
          <h4 class="text-capitalize mb-4">Subscribe Us</h4>
          <p>Subscribe to get latest news article and resources </p>

          <form action="#" class="sub-form">
            <input type="text" class="form-control mb-3" placeholder="Subscribe Now ...">
            <a href="#" class="btn btn-main btn-small">subscribe</a>
          </form>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6">
        <div class="widget">
          <div class="logo mb-4">
            <h3>Mega<span>kit.</span></h3>
          </div>
          <h6><a href="mailto:support@gmail.com">Support@megakit.com</a></h6>
          <a href="tel:+23-345-67890"><span class="text-color h4">+23-456-6588</span></a>
        </div>
      </div>
    </div>

    <div class="footer-btm pt-4">
      <div class="row">
        <div class="col-lg-6">
          <div class="copyright">
            Copyright &copy; 2020, Designed &amp; Developed by <a href="https://themefisher.com/"
              >Themefisher</a>
          </div>
        </div>
        <div class="col-lg-6 text-left text-lg-right">
          <ul class="list-inline footer-socials">
            <li class="list-inline-item"><a href="https://www.facebook.com/themefisher"><i class="fab fa-facebook-f mr-2"></i>Facebook</a></li>
            <li class="list-inline-item"><a href="https://twitter.com/themefisher"><i class="fab fa-twitter mr-2"></i>Twitter</a></li>
            <li class="list-inline-item"><a href="https://www.pinterest.com/themefisher/"><i class="fab fa-pinterest-p mr-2 "></i>Pinterest</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--Scroll to top-->
<div id="scroll-to-top" class="scroll-to-top">
  <span class="icon fa fa-angle-up"></span>
</div>


<!-- 
Essential Scripts
=====================================-->
<!-- Main jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4.3.1 -->
<script src="plugins/bootstrap/bootstrap.min.js"></script>
<!--  Magnific Popup-->
<script src="plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
<!-- Slick Slider -->
<script src="plugins/slick/slick.min.js"></script>
<!-- Counterup -->
<script src="plugins/counterup/jquery.waypoints.min.js"></script>
<script src="plugins/counterup/jquery.counterup.min.js"></script>

<!-- Google Map -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU" defer></script>
<script src="plugins/google-map/map.js" defer></script>

<script src="js/script.js"></script>

</body>
<style>
$("#checkAll").change(function () {
    $("input:checkbox").prop('checked', $(this).prop("checked"));
});
</style>
</html>