<?php
	require_once("config.php");

	$sql =
		"CREATE TABLE User
			(useremail varchar(100),
			 userpassword varchar(50), userphone varchar(15),
			 useraddress varchar(100),

			 primary key(useremail))";

	if(mysql_query($sql,$conn))
	{
		echo "<br/>Table User Created";
	}
	else
	{
		die('<br/>Error Creating Table: '.mysql_error());
	}
	mysql_close($conn);
?>

ALTER TABLE useraccess ADD userIC int, ADD column type;