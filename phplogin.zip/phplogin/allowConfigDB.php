<?php
	$conn = mysql_connect("localhost","admin","admin_123");
		if(!$conn) die ("Error! Cannot connect to server: ".mysql_error());
	$selected = mysql_select_db("db_admin", $conn);
		if(!$selected) die ("cannot use database: ".mysql_error());
?>