<?php
$user = $_POST["emailUser"];
$pass = $_POST["passwordUser"];

require_once("allowConfigDB.php");
session_start();

	$result = mysql_query("SELECT * FROM useraccess WHERE useremail = '$user' and userpassword = '$pass'");

	if (!$result) die("SQL query error encountered :".mysql_error() );

	$row = mysql_fetch_array($result);
	if($row["useremail"]==$user && $row["userpassword"]==$pass && $row["Role"]=="admin")
	{
		$_SESSION["Login"] = $user;
		echo '<script>window.location = "../../project123/Admin/AdminHP.php"</script>';
	}
	else if($row["useremail"]==$user && $row["userpassword"]==$pass && $row["Role"]=="tutor")
	{
		$_SESSION["Login"] = $user;
		echo '<script>window.location = "../../project123/Tutor/TutorHP.php"</script>';
	}
	else if($row["useremail"]==$user && $row["userpassword"]==$pass && $row["Role"]=="student")
	{
		$_SESSION["Login"] = $user;
		echo '<script>window.location = "../../project123/Student/GuestHP.php"</script>';
	}
	else
	{
		echo '<script>alert("Wrong username & password!")</script>';
		echo '<script>window.location = "loginUserFE.php"</script>';
	}

?>

