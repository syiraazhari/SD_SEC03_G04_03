<?php 	

$user = $_POST["emailUser"];

require_once ("allowConfigDB.php");

$result = mysql_query("SELECT useremail FROM useraccess WHERE useremail = '$user'");

if (!$result) die("SQL query error encountered :".mysql_error() );

$row = mysql_fetch_array($result);
if($row["useremail"]==$user)
{
    $query1 = mysql_query("SELECT userpassword FROM useraccess WHERE useremail = '$user'");
    if (!$query1) die("SQL query error encountered :".mysql_error() );

    $row1 = mysql_fetch_array($query1);
    $userpassword = $row1["userpassword"];
    echo '<script>alert("Your password is: '.$userpassword.'")</script>';
    echo '<script>window.location = "loginUserFE.php"</script>';
}
else
{
    echo '<script>alert("Wrong username & password!")</script>';
    echo '<script>window.location = "changePassFE.php"</script>';
}

?>